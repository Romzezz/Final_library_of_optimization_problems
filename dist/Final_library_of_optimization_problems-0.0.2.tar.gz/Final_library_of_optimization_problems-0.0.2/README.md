<html>
	<body>
		<h2>Оптимизационные задачи в машинном обучении. <br> Проект № 9: Final library of optimization problems.</h2>
		<hr>
		<h3>Документация</h3>
		<h4>Всю документацию о проекте вы можете найти <a href = "documentation.pdf">здесь</a></h4>
		<hr>
		<h4>Примеры решения задач можно увидеть в <a href="https://colab.research.google.com/drive/1Jh_mwS2dF3HvwdRFIzZRMcY3_pU8OFlV?usp=sharing">Google Colab</a> </h4>
		<hr>
		<h3>Участники проекта</h3>
		<h4>
		<li>Белоцерковский Даниил - Менеджер проектa</li>
		<li>Хасыков Бата - Программист</li>
		<li>Пучков Александр - Аналитик</li>
		<li>Поплевин Роман - Аналитик, Тестировщик</li>
		<li>Бады Денис - Тестировщик</li>
		<br>
		Группа ПМ19-3
		</h4>
  </body>

</html>
